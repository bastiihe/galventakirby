<?php

// Redirect to the page where the module appears
go($page->page());
