<?php

l::set('selector.empty', 'No matching files yet.');
l::set('selector.select', 'Select');
