<?php

l::set('selector.empty', 'Keine passenden Dateien gefunden.');
l::set('selector.select', 'Auswählen');
